import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.regex.MatchResult;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class DocumentationPage {
    WebDriver driver;
    public DocumentationPage(WebDriver driver) {
        this.driver = driver;
    }

    String DocumentationPageURL = "https://piskvorky.jobs.cz/api/doc";


    By createUserAPIDiv = By.xpath("//div[@id=\"operations-User-post_api_v1_user\"]//div[@class=\"opblock-summary-description\"]");
    By createUserAPITryItOutButton = By.xpath("//div[@class=\"opblock-section-header\"]//button[@class=\"btn try-out__btn\"]");
    By textAreaCreateUserAPI = By.xpath("//textarea[@class=\"body-param__text\"]");
    By CreateUserAPIExecuteButton = By.xpath("(//div[@class=\"opblock-tag-section is-open\"])[1]//button[@class=\"btn execute opblock-control__btn\"]");

    By resposeOfCreateUserAPI = By.xpath("//pre[@class=\" microlight\"]");

    public void clickOnCreateUserAPIDiv()
    {
        driver.findElement(createUserAPIDiv).click();
    }
    public void clickOnCreateUserTextArea()
    {
        driver.findElement(textAreaCreateUserAPI).click();
    }

    public void clickOnCreateUserAPITryItOutButton()
    {
        driver.findElement(createUserAPITryItOutButton).click();
    }

    public void clearCreateUserAPITryItOutButton()
    {
        driver.findElement(textAreaCreateUserAPI).clear();
    }

    public void writeOnCreateUserAPITryItOutButton(String text)
    {
        driver.findElement(textAreaCreateUserAPI).sendKeys(text);
    }

    public void ClickOnExecuteButton(By webElement)
    {
        driver.findElement(webElement).click();
    }

    public String GetAPIresponse(By webElement)
    {
        String text = driver.findElement(webElement).getText();
        return text;
    }

  /*  public boolean useRegex(final String input) {
        // Compile regular expression
         Pattern pattern = Pattern.compile("\".*\"", Pattern.CASE_INSENSITIVE);
        // Match regex against input
         Matcher matcher = pattern.matcher(input);
        // Use results...
        return matcher.matches();
    }*/
    public String getUserIDfromResponse(String response)
    {
       /* the regular expression
        "userId":\s".{1,}"
        */

        String RegularExpressionPattern = "\"userId\":\\s\".{1,}\""; // the matching string must start with "userId:" followed by a space character then followed by " then followed by at least 1 character with any sequence and must end with "
        // set regular expression pattern
        Pattern pattern = Pattern.compile(RegularExpressionPattern);

        Matcher matcher = pattern.matcher(response);

        // Get the current matcher state
        MatchResult result = matcher.toMatchResult();
        //System.out.println("\n Current Matcher: " + result +"\n");

        String matchingText = "";
        while (matcher.find())
        {
            //System.out.println(matcher.group());
            matchingText = matcher.group();
        }
        // Get the group matched using group() method
        return matchingText;



    }



}
