import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;

import java.time.Duration;


public class test {



    @Test
    public void testName() {
        // set up the web driver automatically
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        HomePage homePage = new HomePage(driver);

        // navigate to the homePage
        driver.get(homePage.homePageURL);
        //driver.get(homePage.gameAPIURL);


        int waitTime = 15;
        // explicit wait
        WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(waitTime));
        // wait until start game button is visible
        WebElement startGameButton = wait.until(ExpectedConditions.visibilityOfElementLocated(homePage.startGameButton));

        startGameButton.click();
        System.out.println("Clicked on the start game button");

        /*// click on the start Game button
        JavascriptExecutor js = (JavascriptExecutor) driver;
        // Call the JavascriptExecutor methods
        js.executeScript("arguments[0].click();", startGameButton);*/

        // documentation page
        DocumentationPage documentationPage = new DocumentationPage(driver);

        documentationPage.clickOnCreateUserAPIDiv();
        System.out.println("Clicked on Create User API Div button");


        // wait until UserAPITryItOutButton is visible
        WebElement CreateUserAPITryItOutButton = wait.until(ExpectedConditions.visibilityOfElementLocated(documentationPage.createUserAPITryItOutButton));

        documentationPage.clickOnCreateUserAPITryItOutButton();
        System.out.println("Clicked on Create User API Try It Out Div button");

        WebElement textAreaCreateUserAPI = wait.until(ExpectedConditions.visibilityOfElementLocated(documentationPage.textAreaCreateUserAPI));

        // click on text area
        documentationPage.clickOnCreateUserTextArea();
        System.out.println("Clicked on Create User TextArea");
        // clear the text Area
        documentationPage.clearCreateUserAPITryItOutButton();
        System.out.println("Cleared text on Create User TextArea");

        // write on the text Area
        PlayerData player =  new PlayerData();

        documentationPage.writeOnCreateUserAPITryItOutButton(player.UserData);
        System.out.println("wrote JSON data on Create User TextArea");

        // click on execute button to create player ID
        documentationPage.ClickOnExecuteButton(documentationPage.CreateUserAPIExecuteButton);
        System.out.println("clicked on execute button");

        // get the response text and extract the player ID
        WebElement APICreateUserResponse = wait.until(ExpectedConditions.visibilityOfElementLocated(documentationPage.resposeOfCreateUserAPI));

        String APIcreatedUserResponse = documentationPage.GetAPIresponse(documentationPage.resposeOfCreateUserAPI);
        System.out.println("printing create API User Response\n=====================\n");
        System.out.println(APIcreatedUserResponse);

        // printing userID to test my method
        System.out.println("\n printing userID \n");
        String userId = documentationPage.getUserIDfromResponse(APIcreatedUserResponse);
        System.out.println(userId);



    }
}
