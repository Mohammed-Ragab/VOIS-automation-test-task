import org.apache.commons.lang3.RandomStringUtils;


public class PlayerData {


    String nickName = "\"" + RandomStringUtils.randomAlphanumeric(10) + "\"";
    String email =  "\"" + RandomStringUtils.randomAlphanumeric(10) + "@gmail.com" +"\"";

    String UserData =
            "{\n" +
            "\"nickname\":" + nickName + "," + "\n\"email\":" + email + "\n}";
}
